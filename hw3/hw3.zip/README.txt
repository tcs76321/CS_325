TREVOR STAHL
1/26/2019
HW3

TO RUN shopping.py:
- the shopping.txt provided to work on the assignment is NOT included in this submission
- ensure proper files are in current directory/folder, shopping.py(included) and shopping.txt(need to add file to directory)
- cmd: python shopping.py
- the current folder/directory will now contain results.txt based on the contents of the added shopping.txt