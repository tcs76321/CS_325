Trevor Stahl
stahltr@oregonstate.edu

To run my code follow below:
-ensure the current directory is correct
-ensure there is the appropriate bin.txt file within directory as well as my binpack.py file
-CMD: python binpack.py
-Output will be written to terminal