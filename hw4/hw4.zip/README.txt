Trevor Stahl
2/1/2019
HW4
CS 325 400 w2019

How to run last_to_start.py
-ensure that there is a act.txt file in directory with proper data inside it
-CMD: python last_to_start.py
-output will be printed to screen
