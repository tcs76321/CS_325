TREVOR STAHL
1/14/2019

ANALYSIS OF ALGORITHMS (CS_325_400_W2019)

HW2

to run mergesort4.cpp:

-place a data.txt file in folder with program

-cmd: g++ -o mergesort4 mergesort4.cpp

-program will auto exit

-merge4.txt is now created with correct sorted data





to run mergesort4time.cpp

-cmd: g++ -std=c++11 -o mergesort4time mergesort4time.cpp

-program prints to terminal results with size and time duration

-press enter to exit program

