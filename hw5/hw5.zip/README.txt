stahltr@oregonstate.edu
Trevor Stahl

hw5 - wrestler.py

TO RUN PROGRAM on wrestler1.txt
cmd:
python wrestler.py wrestler1.txt

REPLACE wrestler1.txt with any file name you need to test on for example:
python wrestler.py wrestler2.txt