Trevor Stahl
1/11/2019

ANALYSIS OF ALGORITHMS (CS_325_400_W2019)

HW1

Inlcuded in this file is the same data.txt file from the hw assignment instructions.


To run mergesort.cpp
cmd:
g++ -o mergesort mergesort.cpp
cmd:
mergesort

then merge.txt will be created after running mergsort



To run insertsort.cpp
cmd:
g++ -o insertsort insertsort.cpp 
cmd:
insertsort
cmd:
*press enter*

contents of insert.txt are printed and then waits for user to press enter to continue

and then insert.txt will be created, a sorted file 





To run insertTime.cpp
this program is self enclosed
cmd:
g++ -o inserttime -std=c++11 insertTime.cpp
cmd:
inserttime
cmd:
*press enter*

sizes and durations are printed as they are calculated,
 program waits at then end for user input to finish, just press enter



To run mergetime.cpp
this program is self enclosed
cmd:
g++ -o mergetime -std=c++11 mergetime.cpp
cmd:
mergetime
cmd:
*press enter*

sizes and durations are printed as they are calculated,
 program waits at then end for user input to finish, just press enter

